const express = require('express');
const { engine } = require('express-handlebars');
const { create } = require('express-handlebars');
const bodyparser = require('body-parser');
const path = require('path');
const app = express();

const fakedata = [
    {
        id: 1,
        nome:'Cadeira Comfort',
        mod: '0987',
        qtd: '500',
        esp: 'Sim',
        esto:'Não',
        end: 'C10P04M08',
        obs: 'Utilizar padrão de empilhamento cod067.'
    },
    {
        id: 2,
        nome:'Mesa Oceanside',
        mod: '4563',
        qtd: '400',
        esp: 'Sim',
        esto:'Sim',
        end: 'C09P03M07',
        obs: '-'
    }
];
/*Configura a engine (motor) do express para utilizar o handlebars */
app.use(bodyparser.urlencoded({extended: false}));
app.set('view engine','handlebars');
app.engine('handlebars', engine());

create({}).handlebars.registerHelper('checked', function(value, test) {
    if (value == undefined) return '';
    return value==test ? 'checked' : '';
});
/*disponibilizando acesso para as bibliotecas estaticas do bootstrap e jquery */
app.use('/css', express.static(path.join(__dirname, 'node_modules/bootstrap/dist/css')));
app.use('/js', express.static(path.join(__dirname, 'node_modules/bootstrap/dist/js')));
app.use('/js', express.static(path.join(__dirname, 'node_modules/jquery/dist')));
app.use('/public', express.static(path.join(__dirname, 'public')));

app.get('/', function(req,res){
    res.render('index');
});

app.get('/prods/delete/:id', function(req,res){
    let umprod = fakedata.find(o => o.id == req.params['id']);
    let index = fakedata.indexOf(umprod);
    if (index > -1){
        fakedata.splice(index,1);
    }
    res.render('prod/prods',{data: fakedata});
});


app.get('/prods/novo', function(req,res){
    res.render('prod/formprod');
});

app.get('/prods/alterar/:id', function(req,res){
    let idprod = req.params['id'];
    let umprod = fakedata.find( o => o.id == idprod);
    
    res.render('prod/formprod', {prod: umprod});
    
});



app.post('/prods/save', function(req,res){
    let prodantigo = fakedata.find(o => o.id == req.body.id);

    if(prodantigo != undefined){
        /*ALTERAR */
        prodantigo.nome = req.body.nome;
        prodantigo.mod = req.body.mod;
        prodantigo.qtd = req.body.qtd;
        prodantigo.esp = req.body.esp;
        prodantigo.esto = req.body.esto;
        prodantigo.end = req.body.end;
        prodantigo.obs = req.body.obs;
    }else{
        /*INCLUIR */
        let maxid = Math.max(...fakedata.map( o => o.id));
        if (maxid == -Infinity) maxid = 0;

        let novoprod = {
            nome: req.body.nome,
            mod: req.body.mod,
            qtd: req.body.qtd,
            esp: req.body.esp,
            esto: req.body.esto,
            end: req.body.end,
            obs: req.body.obs,
            id: maxid + 1
            
        };
        fakedata.push(novoprod);
    }
    res.redirect("/prods");
});


app.get('/prods', function(req,res){
    res.render('prod/prods', {listaprods: fakedata});
});

/*inicialização da aplicação NodeJS + Express */
app.listen(3000, () =>{
    console.log('Server online - http://localhost:3000/');
});
